import mongoose, { Schema, Document } from "mongoose";
import { cleanupChefData } from "../controllers/chef.controller";

export interface IBannerImage {
  url: string;
  cloudinaryId: string;
}

export interface IKitchenImage {
  url: string;
  cloudinaryId: string;
}

export type CouponServiceType = "catering" | "mealbox" | "homemade" | "quickbites";

export interface ICouponItem {
  _id?: string;
  code: string;
  type: "percent" | "flat";
  value: string;
  description: string;
  minOrder?: number;
  maxDiscount?: number;
  serviceType: CouponServiceType;
}

export interface IReviewItem {
  _id?: mongoose.Types.ObjectId;
  orderId: string;
  userId?: string;
  userName: string;
  userAvatar?: string;
  rating: number;
  comment: string;
  images: Array<{ url: string; cloudinaryId: string }>;
  createdAt: Date;
}

export interface IChefGeoLocation {
  type: "Point";
  /** GeoJSON coordinates are always [longitude, latitude]. */
  coordinates: [number, number];
}

export interface IChef extends Document {
  user: mongoose.Types.ObjectId;
  name: string;
  exp: string;
  phone: string;
  aadhar: string;
  location: string;
  /** Optional GPS point used to find chefs near a delivery address. */
  geoLocation?: IChefGeoLocation;
  specialty: string;
  price: string;
  foodType: "VEG" | "NONVEG" | "BOTH";
  fssaiNo?: string;
  avatar: string;
  avatarCloudinaryId: string;

  coupons: ICouponItem[];
  banners: IBannerImage[];
  kitchenImages: IKitchenImage[];
  reviews: IReviewItem[];
  averageRating: number;
  totalReviews: number;
  isAvailable: boolean;
  orderHistory: mongoose.Types.ObjectId[];

  bankAccountHolderName: string;
  bankAccountNumber: string;
  bankIfscCode: string;
  upiMobileNumber: string;

  rating?: string;
  createdAt: Date;
  updatedAt: Date;
}

const bannerImageSchema = new Schema<IBannerImage>(
  {
    url: { type: String, required: true },
    cloudinaryId: { type: String, default: "" },
  },
  { _id: false }
);

const kitchenImageSchema = new Schema<IKitchenImage>(
  {
    url: { type: String, required: true },
    cloudinaryId: { type: String, default: "" },
  },
  { _id: false }
);

const couponItemSchema = new Schema<ICouponItem>(
  {
    code: { type: String, required: true, uppercase: true, trim: true },
    type: { type: String, enum: ["percent", "flat"], default: "percent" },
    value: { type: String, required: true, trim: true },
    description: { type: String, default: "", trim: true },
    minOrder: { type: Number, default: 0 },
    maxDiscount: { type: Number, default: 500 },
    serviceType: {
      type: String,
      enum: ["catering", "mealbox", "homemade", "quickbites"],
      default: "catering",
      lowercase: true,
      trim: true,
    },
  },
  { _id: true, timestamps: true }
);

const reviewItemSchema = new Schema<IReviewItem>(
  {
    orderId: { type: String, required: true },
    userId: { type: String, default: "" },
    userName: { type: String, required: true, default: "Customer" },
    userAvatar: { type: String, default: "" },
    rating: { type: Number, required: true, min: 1, max: 5 },
    comment: { type: String, default: "", trim: true },
    images: {
      type: [
        {
          url: { type: String, required: true },
          cloudinaryId: { type: String, default: "" },
        },
      ],
      default: [],
    },
  },
  { _id: true, timestamps: true }
);

const chefGeoLocationSchema = new Schema<IChefGeoLocation>(
  {
    type: { type: String, enum: ["Point"], required: true, default: "Point" },
    coordinates: {
      type: [Number],
      required: true,
      validate: {
        validator: function (coordinates: number[]) {
          return (
            Array.isArray(coordinates) &&
            coordinates.length === 2 &&
            coordinates.every((coordinate) => Number.isFinite(coordinate))
          );
        },
        message: "Chef GPS coordinates must contain longitude and latitude",
      },
    },
  },
  { _id: false }
);

const chefSchema = new Schema<IChef>(
  {
    user: {
      type: Schema.Types.ObjectId,
      ref: "User",
      required: true,
      unique: true,
    },
    name: { type: String, required: true },
    exp: { type: String, required: true },
    phone: {
      type: String,
      default: "",
      trim: true,
      validate: {
        validator: function (v: string) {
          if (!v) return true;
          return /^\d{10}$/.test(v);
        },
        message: "Phone number must be exactly 10 digits",
      },
    },
    aadhar: {
      type: String,
      default: "",
      trim: true,
      validate: {
        validator: function (v: string) {
          if (!v) return true;
          return /^\d{12}$/.test(v);
        },
        message: "Aadhar number must be exactly 12 digits",
      },
    },
    location: { type: String, required: true },
    geoLocation: {
      type: chefGeoLocationSchema,
      default: undefined,
    },
    specialty: { type: String, required: true },
    price: { type: String, required: true },
    foodType: {
      type: String,
      enum: ["VEG", "NONVEG", "BOTH"],
      default: "BOTH",
    },
    fssaiNo: { type: String, default: "" },
    avatar: { type: String, required: true },
    avatarCloudinaryId: { type: String, default: "" },

    coupons: { type: [couponItemSchema], default: [] },
    banners: { type: [bannerImageSchema], default: [] },
    kitchenImages: { type: [kitchenImageSchema], default: [] },
    reviews: { type: [reviewItemSchema], default: [] },
    averageRating: { type: Number, default: 4.8 },
    totalReviews: { type: Number, default: 0 },
    isAvailable: { type: Boolean, default: true },

    orderHistory: [
      {
        type: Schema.Types.ObjectId,
        ref: "Order",
      },
    ],

    bankAccountHolderName: { type: String, default: "", trim: true },
    bankAccountNumber: { type: String, default: "", trim: true },
    bankIfscCode: { type: String, default: "", trim: true, uppercase: true },
    upiMobileNumber: {
      type: String,
      default: "",
      trim: true,
      validate: {
        validator: function (v: string) {
          if (!v) return true;
          return /^\d{10}$/.test(v);
        },
        message: "UPI mobile number must be exactly 10 digits",
      },
    },

    rating: { type: String, default: "4.8" },
  },
  { timestamps: true }
);

// GeoJSON index supports future MongoDB $near queries. Existing documents
// without geoLocation remain valid and do not need a migration.
chefSchema.index({ geoLocation: "2dsphere" });

chefSchema.post("deleteOne", { document: true, query: false }, async function () {
  const chef = this as any;
  if (chef?._id && chef?.user) {
    await cleanupChefData(chef._id.toString(), chef.user.toString());
  }
});

chefSchema.post("findOneAndDelete", async function (doc: any) {
  if (doc?._id && doc?.user) {
    await cleanupChefData(doc._id.toString(), doc.user.toString());
  }
});

export default mongoose.models.Chef || mongoose.model<IChef>("Chef", chefSchema);
