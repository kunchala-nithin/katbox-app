import { Request, Response } from "express";



import cloudinary from "../config/cloudinary";



import Chef from "../models/Chef";



import User from "../models/User";



import { ChefMenu } from "../models/chefCategory";



import jwt from "jsonwebtoken";



import mongoose from "mongoose";
import { emitChefAccessChanged } from "../utils/socket";







// ============================================================



// CLOUDINARY UPLOAD PRESETS (STRICT COMPRESSION)



// ============================================================



type UploadKind = "avatar" | "banner" | "kitchen";







const UPLOAD_PRESETS: Record<UploadKind, any> = {



  avatar: {



    folder: "chefs/avatars",



    resource_type: "image",



    transformation: [



      {



        width: 500,



        height: 500,



        crop: "fill",



        gravity: "face",



        quality: "auto:eco",



        fetch_format: "auto",



        flags: "progressive",



      },



    ],



  },



  banner: {



    folder: "chefs/banners",



    resource_type: "image",



    transformation: [



      {



        width: 1400,



        height: 900,



        crop: "limit",



        quality: "auto:good",



        fetch_format: "auto",



        flags: "progressive",



      },



    ],



  },



  kitchen: {



    folder: "chefs/kitchens",



    resource_type: "image",



    transformation: [



      {



        width: 1200,



        height: 1200,



        crop: "limit",



        quality: "auto:eco",



        fetch_format: "auto",



        flags: "progressive",



      },



    ],



  },



};







// ✅ Allowed coupon service types (lowercase canonical form)



const COUPON_SERVICE_TYPES = ["catering", "mealbox", "homemade", "quickbites"] as const;



type CouponServiceType = (typeof COUPON_SERVICE_TYPES)[number];







const normalizeCouponServiceType = (raw: any): CouponServiceType => {



  const s = String(raw || "").toLowerCase().trim();



  return (COUPON_SERVICE_TYPES as readonly string[]).includes(s)



    ? (s as CouponServiceType)



    : "catering";



};







// ================= SHARED CLEANUP FUNCTION =================



export const cleanupChefData = async (chefId: string, userId: string) => {



  try {



    // 1. Find and delete all menus + their images



    const menus = await ChefMenu.find({ chef: chefId });







    for (const menu of menus) {



      if (menu.heroCloudinaryId) {



        try { await cloudinary.uploader.destroy(menu.heroCloudinaryId); } catch (e) { }



      }







      for (const item of menu.plateItems || []) {



        if (item.cloudinaryId) {



          try { await cloudinary.uploader.destroy(item.cloudinaryId); } catch (e) { }



        }



      }







      if (menu.daawathCategories && menu.daawathCategories.length > 0) {



        for (const cat of menu.daawathCategories) {



          if (cat.cloudinaryId) {



            try { await cloudinary.uploader.destroy(cat.cloudinaryId); } catch (e) { }



          }



          for (const item of cat.items || []) {



            if (item.cloudinaryId) {



              try { await cloudinary.uploader.destroy(item.cloudinaryId); } catch (e) { }



            }



          }



        }



      }







      await ChefMenu.findByIdAndDelete(menu._id);



    }







    // 2. Delete chef's avatar & all banner images



    const chef = await Chef.findById(chefId);



    if (chef) {



      if (chef.avatarCloudinaryId) {



        try { await cloudinary.uploader.destroy(chef.avatarCloudinaryId); } catch (e) { }



      }



      if (chef.banners && chef.banners.length > 0) {



        for (const b of chef.banners) {



          if (b.cloudinaryId) {



            try { await cloudinary.uploader.destroy(b.cloudinaryId); } catch (e) { }



          }



        }



      }



      if (chef.kitchenImages && chef.kitchenImages.length > 0) {



        for (const image of chef.kitchenImages) {



          if (image.cloudinaryId) {



            try { await cloudinary.uploader.destroy(image.cloudinaryId); } catch (e) { }



          }



        }



      }



    }







    // 3. Delete the chef document



    await Chef.findByIdAndDelete(chefId);







    // 4. Reset user flag



    if (userId) {



      await User.findByIdAndUpdate(userId, { isChef: false });



    }







    console.log(`✅ Full cleanup completed for chef: ${chefId}`);



  } catch (err) {



    console.error("Cleanup error:", err);



  }



};







// ================= RECALCULATE CHEF RATING HELPER =================



export const recalculateChefRating = async (chefId: string | mongoose.Types.ObjectId) => {



  try {



    const chef = await Chef.findById(chefId);



    if (!chef) return null;







    const reviews = Array.isArray(chef.reviews) ? chef.reviews : [];



    const totalReviews = reviews.length;







    let averageRating = 4.8;



    if (totalReviews > 0) {



      const sum = reviews.reduce((acc: number, r: any) => acc + (Number(r.rating) || 0), 0);



      averageRating = Number((sum / totalReviews).toFixed(1));



    }







    chef.totalReviews = totalReviews;



    chef.averageRating = averageRating;



    chef.rating = String(averageRating);







    await chef.save();







    return { averageRating, totalReviews };



  } catch (err) {



    console.error("recalculateChefRating error:", err);



    return null;



  }



};







// ================= DELETE SINGLE IMAGE FROM CLOUDINARY =================



export const deleteChefImage = async (req: any, res: Response) => {



  try {



    const { publicId } = req.body;







    if (!publicId) {



      return res.status(400).json({ message: "publicId is required" });



    }







    await cloudinary.uploader.destroy(publicId);







    return res.json({



      success: true,



      message: "Image deleted from Cloudinary",



    });



  } catch (err: any) {



    console.error("Cloudinary delete error:", err);







    return res.status(500).json({



      message: "Failed to delete image",



    });



  }



};







// ============================================================



// UPLOAD BUFFER → CLOUDINARY (STRICT COMPRESSION APPLIED)



// ============================================================



const uploadFromBuffer = (



  fileBuffer: Buffer,



  kind: UploadKind = "banner"



) => {



  return new Promise<any>((resolve, reject) => {



    const preset = UPLOAD_PRESETS[kind];







    const stream = cloudinary.uploader.upload_stream(



      preset,



      (error, result) => {



        if (error) reject(error);



        else resolve(result);



      }



    );







    stream.end(fileBuffer);



  });



};







// Auth middleware



export const protect = (req: any, res: Response, next: any) => {



  try {



    const token = req.headers.authorization?.split(" ")[1];







    if (!token) {



      return res.status(401).json({ message: "No token provided" });



    }







    const decoded: any = jwt.verify(



      token,



      process.env.JWT_SECRET as string



    );







    req.user = { id: decoded.userId, _id: decoded.userId, userId: decoded.userId };



    next();



  } catch (err) {



    console.log("Auth error:", err);







    return res.status(401).json({



      message: "Invalid or expired token",



    });



  }



};







export const createOrUpdateChef = async (req: any, res: Response) => {



  try {



    const {



      name,



      exp,



      phone,



      aadhar,



      location,



      latitude,



      longitude,



      specialty,



      price,



      foodType,



      fssaiNo,



      isAvailable,



      coupons,



      existingBanners,



      deletedBannerIds,



      existingKitchenImages,



      deletedKitchenImageIds,



      removeAvatarOnSave,



      // ✅ NEW: bank / payout info



      bankAccountHolderName,



      bankAccountNumber,



      bankIfscCode,



      upiMobileNumber,



    } = req.body;







    const userId = req.user.id;



    const files = (req.files as { [fieldname: string]: Express.Multer.File[] }) || {};







    const avatarFiles = files["avatar"] || [];



    const bannerFiles = files["banners"] || [];



    const kitchenImageFiles = files["kitchenImages"] || [];







    const parsedLatitude =

      latitude !== undefined && String(latitude).trim() !== ""

        ? Number(latitude)

        : undefined;

    const parsedLongitude =

      longitude !== undefined && String(longitude).trim() !== ""

        ? Number(longitude)

        : undefined;

    const hasValidChefCoordinates =

      parsedLatitude !== undefined &&

      parsedLongitude !== undefined &&

      Number.isFinite(parsedLatitude) &&

      Number.isFinite(parsedLongitude) &&

      parsedLatitude >= -90 &&

      parsedLatitude <= 90 &&

      parsedLongitude >= -180 &&

      parsedLongitude <= 180;

    const geoLocation: { type: "Point"; coordinates: [number, number] } | undefined =

      hasValidChefCoordinates

        ? {

            type: "Point",

            coordinates: [parsedLongitude as number, parsedLatitude as number],

          }

        : undefined;



    const existingChef = await Chef.findOne({ user: userId });







    // ─── SANITIZE PHONE (10 digits strict) ───



    const sanitizedPhone = String(phone || "").replace(/\D/g, "").slice(0, 10);



    // ─── SANITIZE AADHAR (12 digits strict) ───



    const sanitizedAadhar = String(aadhar || "").replace(/\D/g, "").slice(0, 12);



    // ─── SANITIZE UPI MOBILE (10 digits strict) ───



    const sanitizedUpiMobile = String(upiMobileNumber || "")



      .replace(/\D/g, "")



      .slice(0, 10);



    // ─── SANITIZE IFSC (uppercase, alphanumeric only) ───



    const sanitizedIfsc = String(bankIfscCode || "")



      .replace(/[^a-zA-Z0-9]/g, "")



      .toUpperCase();







    // Parse coupons array safely if passed as JSON string



    let parsedCoupons: any[] = [];



    if (coupons) {



      try {



        const raw = typeof coupons === "string" ? JSON.parse(coupons) : coupons;



        if (Array.isArray(raw)) {



          parsedCoupons = raw.map((c: any) => ({



            code: String(c.code || "").trim().toUpperCase(),



            type: c.type === "flat" ? "flat" : "percent",



            value: String(c.value || "").trim(),



            description: String(c.description || "").trim(),



            minOrder: Number(c.minOrder) || 0,



            maxDiscount: Number(c.maxDiscount) || 500,



            serviceType: normalizeCouponServiceType(c.serviceType),



          }));



        }



      } catch (e) {



        console.log("Error parsing coupons", e);



      }



    }







    // 1. Process deleted banner IDs from Cloudinary



    if (deletedBannerIds) {



      try {



        const toDelete: string[] = JSON.parse(deletedBannerIds);



        for (const pubId of toDelete) {



          if (pubId) {



            await cloudinary.uploader.destroy(pubId).catch(() => {});



          }



        }



      } catch (e) {



        console.log("Error parsing deletedBannerIds", e);



      }



    }







    // 2. Parse existing banners retained by the user



    let retainedBanners: { url: string; cloudinaryId: string }[] = [];



    if (existingBanners) {



      try {



        retainedBanners = JSON.parse(existingBanners);



      } catch (e) {



        console.log("Error parsing existingBanners", e);



      }



    }







    // 3. Upload new banner files to Cloudinary (STRICT COMPRESSION)



    const newlyUploadedBanners: { url: string; cloudinaryId: string }[] = [];



    for (const bFile of bannerFiles) {



      const upload: any = await uploadFromBuffer(bFile.buffer, "banner");



      newlyUploadedBanners.push({



        url: upload.secure_url,



        cloudinaryId: upload.public_id,



      });



    }







    const finalBanners = [...retainedBanners, ...newlyUploadedBanners];



    // Process removed kitchen images and retain only images still selected by the chef.



    let deletedKitchenIds: string[] = [];



    if (deletedKitchenImageIds) {



      try {



        deletedKitchenIds = JSON.parse(deletedKitchenImageIds);



        for (const publicId of deletedKitchenIds) {



          if (publicId) await cloudinary.uploader.destroy(publicId).catch(() => {});



        }



      } catch (error) {



        console.log("Error parsing deletedKitchenImageIds", error);



      }



    }



    let retainedKitchenImages: { url: string; cloudinaryId: string }[] = [];



    if (existingKitchenImages) {



      try {



        retainedKitchenImages = JSON.parse(existingKitchenImages);



      } catch (error) {



        console.log("Error parsing existingKitchenImages", error);



      }



    }



    const newlyUploadedKitchenImages: { url: string; cloudinaryId: string }[] = [];



    for (const kitchenFile of kitchenImageFiles) {



      const upload: any = await uploadFromBuffer(kitchenFile.buffer, "kitchen");



      newlyUploadedKitchenImages.push({



        url: upload.secure_url,



        cloudinaryId: upload.public_id,



      });



    }



    const finalKitchenImages = [...retainedKitchenImages, ...newlyUploadedKitchenImages];







    let chef;







    if (existingChef) {



      let avatarUrl = existingChef.avatar;



      let avatarCloudinaryId = existingChef.avatarCloudinaryId;







      // ─── AVATAR REPLACEMENT ───



      if (avatarFiles.length > 0) {



        if (existingChef.avatarCloudinaryId) {



          await cloudinary.uploader



            .destroy(existingChef.avatarCloudinaryId)



            .catch(() => {});



        }



        const upload: any = await uploadFromBuffer(avatarFiles[0].buffer, "avatar");



        avatarUrl = upload.secure_url;



        avatarCloudinaryId = upload.public_id;



      } else if (



        String(removeAvatarOnSave) === "true" &&



        existingChef.avatarCloudinaryId



      ) {



        await cloudinary.uploader



          .destroy(existingChef.avatarCloudinaryId)



          .catch(() => {});



        avatarUrl = "";



        avatarCloudinaryId = "";



      }







      existingChef.name = name;



      existingChef.exp = exp;



      existingChef.phone = sanitizedPhone;



      existingChef.aadhar = sanitizedAadhar;



      existingChef.location = location;

      if (geoLocation) {

        (existingChef as any).geoLocation = geoLocation;

      }



      existingChef.specialty = specialty;



      existingChef.price = price;



      existingChef.foodType = foodType;



      existingChef.fssaiNo = fssaiNo || "";



      existingChef.avatar = avatarUrl;



      existingChef.avatarCloudinaryId = avatarCloudinaryId;



      existingChef.coupons = parsedCoupons;



      existingChef.banners = finalBanners;



      existingChef.kitchenImages = finalKitchenImages;







      // ✅ NEW: bank / payout info



      existingChef.bankAccountHolderName = String(bankAccountHolderName || "").trim();



      existingChef.bankAccountNumber = String(bankAccountNumber || "").trim();



      existingChef.bankIfscCode = sanitizedIfsc;



      existingChef.upiMobileNumber = sanitizedUpiMobile;







      existingChef.isAvailable =



        typeof isAvailable !== "undefined"



          ? isAvailable === "true" || isAvailable === true



          : existingChef.isAvailable;







      chef = await existingChef.save();



      return res.json({ success: true, chef });



    } else {



      let avatarUrl = "";



      let avatarCloudinaryId = "";







      if (avatarFiles.length > 0) {



        const avatarUpload: any = await uploadFromBuffer(



          avatarFiles[0].buffer,



          "avatar"



        );



        avatarUrl = avatarUpload.secure_url;



        avatarCloudinaryId = avatarUpload.public_id;



      }







      chef = await Chef.create({



        user: userId,



        name,



        exp,



        phone: sanitizedPhone,



        aadhar: sanitizedAadhar,



        location,

        ...(geoLocation ? { geoLocation } : {}),



        specialty,



        price,



        foodType,



        fssaiNo: fssaiNo || "",



        avatar: avatarUrl,



        avatarCloudinaryId,



        coupons: parsedCoupons,



        banners: finalBanners,



        kitchenImages: finalKitchenImages,



        isAvailable: isAvailable === "false" ? false : true,



        // ✅ NEW: bank / payout info



        bankAccountHolderName: String(bankAccountHolderName || "").trim(),



        bankAccountNumber: String(bankAccountNumber || "").trim(),



        bankIfscCode: sanitizedIfsc,



        upiMobileNumber: sanitizedUpiMobile,



      });







      // Chef profile creation does not approve the account.
      // Only an explicit admin action may set User.isChef = true.



      return res.json({ success: true, chef });



    }



  } catch (err: any) {



    console.error("Save chef error:", err);



    res.status(500).json({ message: "Server error while saving chef", error: err.message });



  }



};







// FULL DELETE CHEF (via API)



export const deleteChef = async (req: any, res: Response) => {



  try {



    const userId = req.user.id;



    const chef = await Chef.findOne({ user: userId });



    if (!chef) {



      return res.status(404).json({ message: "Chef not found" });



    }







    await cleanupChefData(chef._id.toString(), userId);







    return res.json({



      success: true,



      message: "Chef profile and ALL related data deleted permanently",



    });



  } catch (err: any) {



    console.error("Delete chef error:", err);



    return res.status(500).json({



      message: "Server error while deleting chef",



      error: err.message,



    });



  }



};







// ============================================================



// GET ALL CHEFS (CUSTOMER-FACING)



// ============================================================



export const getChefs = async (req: Request, res: Response) => {
  try {
    const latitudeRaw = req.query.latitude;
    const longitudeRaw = req.query.longitude;
    const hasCoordinates =
      latitudeRaw !== undefined &&
      longitudeRaw !== undefined &&
      String(latitudeRaw).trim() !== "" &&
      String(longitudeRaw).trim() !== "";

    const customerLatitude = Number(latitudeRaw);
    const customerLongitude = Number(longitudeRaw);
    const coordinatesAreValid =
      hasCoordinates &&
      Number.isFinite(customerLatitude) &&
      Number.isFinite(customerLongitude) &&
      customerLatitude >= -90 &&
      customerLatitude <= 90 &&
      customerLongitude >= -180 &&
      customerLongitude <= 180;

    const parsedRadius = Number(req.query.radiusKm);
    const radiusKm =
      Number.isFinite(parsedRadius) && parsedRadius > 0
        ? Math.min(parsedRadius, 10)
        : 10;

    const distanceBetweenKm = (
      lat1: number,
      lon1: number,
      lat2: number,
      lon2: number
    ) => {
      const toRadians = (degrees: number) => (degrees * Math.PI) / 180;
      const earthRadiusKm = 6371;
      const dLat = toRadians(lat2 - lat1);
      const dLon = toRadians(lon2 - lon1);
      const a =
        Math.sin(dLat / 2) ** 2 +
        Math.cos(toRadians(lat1)) *
          Math.cos(toRadians(lat2)) *
          Math.sin(dLon / 2) ** 2;
      return earthRadiusKm * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    };

    const chefs = await Chef.find().sort({ createdAt: -1 });
    const userIds = chefs.map((chef: any) => chef.user).filter(Boolean);
    const users = userIds.length
      ? await User.find({ _id: { $in: userIds } })
          .select("_id isChef")
          .lean()
      : [];

    const blockedUserIds = new Set<string>(
      users
        .filter((user: any) => user?.isChef === false)
        .map((user: any) => String(user._id))
    );

    const visibleChefs = chefs
      .filter((chef: any) => !blockedUserIds.has(String(chef.user)))
      .map((chef: any) => {
        const chefObject =
          typeof chef.toObject === "function" ? chef.toObject() : { ...chef };
        const coordinates = chefObject?.geoLocation?.coordinates;
        const chefLongitude = Array.isArray(coordinates)
          ? Number(coordinates[0])
          : NaN;
        const chefLatitude = Array.isArray(coordinates)
          ? Number(coordinates[1])
          : NaN;

        const chefCoordinatesAreValid =
          Number.isFinite(chefLatitude) &&
          Number.isFinite(chefLongitude) &&
          chefLatitude >= -90 &&
          chefLatitude <= 90 &&
          chefLongitude >= -180 &&
          chefLongitude <= 180;

        if (coordinatesAreValid && chefCoordinatesAreValid) {
          const distanceKm = distanceBetweenKm(
            customerLatitude,
            customerLongitude,
            chefLatitude,
            chefLongitude
          );
          return {
            ...chefObject,
            distanceKm: Number(distanceKm.toFixed(3)),
            withinRadius: distanceKm <= radiusKm,
          };
        }

        return {
          ...chefObject,
          distanceKm: null,
          withinRadius: false,
        };
      });

    // Keep every visible chef in the response. Chefs within 10 km appear first,
    // sorted nearest-to-farthest; chefs beyond 10 km follow, also by distance.
    // Chefs without saved GPS coordinates are placed last.
    const orderedChefs = coordinatesAreValid
      ? visibleChefs.sort((a: any, b: any) => {
          const aHasDistance = typeof a.distanceKm === "number";
          const bHasDistance = typeof b.distanceKm === "number";

          if (aHasDistance && !bHasDistance) return -1;
          if (!aHasDistance && bHasDistance) return 1;
          if (!aHasDistance && !bHasDistance) return 0;

          if (a.withinRadius !== b.withinRadius) {
            return a.withinRadius ? -1 : 1;
          }
          return a.distanceKm - b.distanceKm;
        })
      : visibleChefs;

    return res.json({
      success: true,
      chefs: orderedChefs,
      ...(coordinatesAreValid
        ? {
            search: {
              latitude: customerLatitude,
              longitude: customerLongitude,
              radiusKm,
              total: orderedChefs.length,
              withinRadius: orderedChefs.filter(
                (chef: any) => chef.withinRadius
              ).length,
            },
          }
        : {}),
    });
  } catch (error) {
    console.error("Get chefs error:", error);
    return res.status(500).json({ message: "Server error" });
  }
};

// ============================================================
// GET ALL CHEFS (ADMIN VIEW)



// ============================================================



export const getAllChefsForAdmin = async (_req: Request, res: Response) => {



  try {



    const chefs = await Chef.find()



      .populate({



        path: "orderHistory",



        select:



          "orderId totalAmount orderStatus serviceType createdAt userName userPhone chefName",



        options: { sort: { createdAt: -1 } },



      })



      .sort({ createdAt: -1 });







    const userIds = chefs



      .map((c: any) => c.user)



      .filter(Boolean);







    const users = await User.find({ _id: { $in: userIds } })



      .select("_id isChef email name phone")



      .lean();







    const userMap = new Map<string, any>();



    users.forEach((u: any) => {



      userMap.set(String(u._id), u);



    });







    const enrichedChefs = chefs.map((chef: any) => {



      const chefObj = typeof chef.toObject === "function" ? chef.toObject() : chef;



      const linkedUser = userMap.get(String(chef.user));







      const userIsChef =



        linkedUser === undefined



          ? true



          : linkedUser?.isChef !== false;







      // Normalize every order into a compact payload



      const rawOrders: any[] = Array.isArray(chefObj.orderHistory)



        ? chefObj.orderHistory.filter(Boolean)



        : [];







      const receivedOrders = rawOrders.map((o: any) => ({



        _id: o._id,



        orderId: o.orderId || "",



        totalAmount: Number(o.totalAmount) || 0,



        orderStatus: o.orderStatus || "Placed",



        serviceType: o.serviceType || "",



        createdAt: o.createdAt || null,



        userName: o.userName || "",



        userPhone: o.userPhone || "",



      }));







      const isDelivered = (status: string) => {



        const s = String(status || "").toLowerCase();



        return (



          s === "delivered" ||



          s === "completed" ||



          s.includes("cash collected") ||



          s.includes("amount collected")



        );



      };







      const deliveredOrders = receivedOrders.filter((o: any) =>



        isDelivered(o.orderStatus)



      );







      const totalEarned = deliveredOrders.reduce(



        (sum: number, o: any) => sum + o.totalAmount,



        0



      );







      return {



        ...chefObj,



        userIsChef,



        userEmail: linkedUser?.email || "",



        userPhone: linkedUser?.phone || "",



        // ✅ NEW: order-history fields consumed by admin UI



        orderCount: receivedOrders.length,



        deliveredCount: deliveredOrders.length,



        totalEarned,



        receivedOrders,



      };



    });







    return res.json({



      success: true,



      chefs: enrichedChefs,



      total: enrichedChefs.length,



    });



  } catch (error: any) {



    console.error("Get all chefs (admin) error:", error);



    return res.status(500).json({



      success: false,



      message: "Failed to fetch chefs for admin",



    });



  }



};







// ============================================================



// TOGGLE CHEF BLOCK STATUS (ADMIN ONLY)



// ============================================================



export const toggleChefBlockStatus = async (req: any, res: Response) => {



  try {



    const rawChefId = req.params.chefId;



    const chefId = Array.isArray(rawChefId) ? rawChefId[0] : rawChefId;







    if (!chefId) {



      return res.status(400).json({



        success: false,



        message: "Chef ID is required",



      });



    }







    const { isChef: forceValue } = req.body || {};







    const query: any = {};



    if (mongoose.Types.ObjectId.isValid(chefId)) {



      query.$or = [{ _id: chefId }, { user: chefId }];



    } else {



      query.$or = [{ name: chefId }];



    }







    const chef = await Chef.findOne(query);



    if (!chef) {



      return res.status(404).json({



        success: false,



        message: "Chef not found",



      });



    }







    const user = await User.findById(chef.user);



    if (!user) {



      return res.status(404).json({



        success: false,



        message: "Linked user account not found for this chef",



      });



    }







    const nextIsChef =



      typeof forceValue === "boolean" ? forceValue : !user.isChef;







    user.isChef = nextIsChef;



    await user.save();







    console.log(



      `🔐 Admin ${nextIsChef ? "UNBLOCKED" : "BLOCKED"} chef '${chef.name}' (chef:${chef._id}, user:${user._id})`



    );







    return res.json({



      success: true,



      message: nextIsChef



        ? `Chef '${chef.name}' has been unblocked and is now active.`



        : `Chef '${chef.name}' has been blocked.`,



      chefId: chef._id,



      chefName: chef.name,



      userId: user._id,



      isChef: user.isChef,



    });



  } catch (error: any) {



    console.error("Toggle chef block status error:", error);



    return res.status(500).json({



      success: false,



      message: "Failed to update chef block status",



    });



  }



};







// ============================================================



// UPDATE CHEF BY ADMIN



// ============================================================



export const updateChefByAdmin = async (req: any, res: Response) => {



  try {



    const rawChefId = req.params.chefId;



    const chefId = Array.isArray(rawChefId) ? rawChefId[0] : rawChefId;







    if (!chefId) {



      return res.status(400).json({ success: false, message: "Chef ID is required" });



    }







    const query: any = {};



    if (mongoose.Types.ObjectId.isValid(chefId)) {



      query.$or = [{ _id: chefId }, { user: chefId }];



    } else {



      query.$or = [{ name: chefId }];



    }







    const chef = await Chef.findOne(query);



    if (!chef) {



      return res.status(404).json({ success: false, message: "Chef not found" });



    }







    const {



      name,



      exp,



      phone,



      aadhar,



      location,



      specialty,



      price,



      foodType,



      fssaiNo,



      isAvailable,



      // ✅ NEW: bank / payout info



      bankAccountHolderName,



      bankAccountNumber,



      bankIfscCode,



      upiMobileNumber,



    } = req.body || {};







    if (typeof name === "string" && name.trim()) chef.name = name.trim();



    if (typeof exp === "string") chef.exp = exp.trim();



    if (typeof phone === "string") {



      chef.phone = phone.replace(/\D/g, "").slice(0, 10);



    }



    if (typeof aadhar === "string") {



      chef.aadhar = aadhar.replace(/\D/g, "").slice(0, 12);



    }



    if (typeof location === "string") chef.location = location.trim();



    if (typeof specialty === "string") chef.specialty = specialty.trim();



    if (typeof price === "string") chef.price = price.trim();



    if (foodType === "VEG" || foodType === "NONVEG" || foodType === "BOTH") {



      chef.foodType = foodType;



    }



    if (typeof fssaiNo === "string") chef.fssaiNo = fssaiNo.trim();



    if (typeof isAvailable === "boolean") chef.isAvailable = isAvailable;







    // ✅ NEW: bank / payout info



    if (typeof bankAccountHolderName === "string") {



      chef.bankAccountHolderName = bankAccountHolderName.trim();



    }



    if (typeof bankAccountNumber === "string") {



      chef.bankAccountNumber = bankAccountNumber.trim();



    }



    if (typeof bankIfscCode === "string") {



      chef.bankIfscCode = bankIfscCode



        .replace(/[^a-zA-Z0-9]/g, "")



        .toUpperCase();



    }



    if (typeof upiMobileNumber === "string") {



      chef.upiMobileNumber = upiMobileNumber.replace(/\D/g, "").slice(0, 10);



    }







    await chef.save();







    return res.json({



      success: true,



      message: "Chef profile updated successfully.",



      chef,



    });



  } catch (error: any) {



    console.error("Update chef by admin error:", error);



    return res.status(500).json({



      success: false,



      message: "Failed to update chef profile.",



    });



  }



};







// ============================================================



// DELETE CHEF BY ADMIN



// ============================================================



export const deleteChefByAdmin = async (req: any, res: Response) => {



  try {



    const rawChefId = req.params.chefId;



    const chefId = Array.isArray(rawChefId) ? rawChefId[0] : rawChefId;







    if (!chefId) {



      return res.status(400).json({ success: false, message: "Chef ID is required" });



    }







    const query: any = {};



    if (mongoose.Types.ObjectId.isValid(chefId)) {



      query.$or = [{ _id: chefId }, { user: chefId }];



    } else {



      query.$or = [{ name: chefId }];



    }







    const chef = await Chef.findOne(query);



    if (!chef) {



      return res.status(404).json({ success: false, message: "Chef not found" });



    }







    await cleanupChefData(chef._id.toString(), chef.user?.toString() || "");







    return res.json({



      success: true,



      message: "Chef and all related data deleted permanently.",



    });



  } catch (error: any) {



    console.error("Delete chef by admin error:", error);



    return res.status(500).json({



      success: false,



      message: "Failed to delete chef.",



    });



  }



};







// ============================================================



// ADD COUPON TO CHEF (ADMIN ONLY)



// ============================================================



export const addChefCouponByAdmin = async (req: any, res: Response) => {



  try {



    const rawChefId = req.params.chefId;



    const chefId = Array.isArray(rawChefId) ? rawChefId[0] : rawChefId;



    if (!chefId) {



      return res.status(400).json({ success: false, message: "Chef ID is required" });



    }







    const query: any = {};



    if (mongoose.Types.ObjectId.isValid(chefId)) {



      query.$or = [{ _id: chefId }, { user: chefId }];



    } else {



      query.$or = [{ name: chefId }];



    }







    const chef = await Chef.findOne(query);



    if (!chef) {



      return res.status(404).json({ success: false, message: "Chef not found" });



    }







    const { code, type, value, description, serviceType } = req.body || {};







    const cleanCode = String(code || "").trim().toUpperCase();



    const cleanValue = String(value || "").trim();



    const cleanType = type === "flat" ? "flat" : "percent";



    const cleanDesc = String(description || "").trim();



    const cleanService = normalizeCouponServiceType(serviceType);







    if (!cleanCode) {



      return res.status(400).json({ success: false, message: "Coupon code is required" });



    }



    if (!cleanValue || isNaN(Number(cleanValue)) || Number(cleanValue) <= 0) {



      return res.status(400).json({ success: false, message: "Enter a valid discount value" });



    }



    if (cleanType === "percent" && Number(cleanValue) > 100) {



      return res.status(400).json({ success: false, message: "Percent discount cannot exceed 100" });



    }







    const alreadyExists = (chef.coupons || []).some(



      (c: any) => String(c.code || "").toUpperCase() === cleanCode



    );



    if (alreadyExists) {



      return res.status(400).json({



        success: false,



        message: "This coupon code already exists for this chef",



      });



    }







    const newCoupon = {



      code: cleanCode,



      type: cleanType,



      value: cleanValue,



      description:



        cleanDesc ||



        (cleanType === "percent" ? `${cleanValue}% OFF` : `Flat ₹${cleanValue} OFF`),



      minOrder: 0,



      maxDiscount: 500,



      serviceType: cleanService,



    };







    chef.coupons.push(newCoupon as any);



    await chef.save();







    console.log(`🎟️ Admin added coupon '${cleanCode}' to chef '${chef.name}'`);







    return res.json({



      success: true,



      message: "Coupon added successfully",



      chef,



      coupons: chef.coupons,



    });



  } catch (error: any) {



    console.error("Add chef coupon (admin) error:", error);



    return res.status(500).json({



      success: false,



      message: "Failed to add coupon",



    });



  }



};







// ============================================================



// DELETE COUPON FROM CHEF (ADMIN ONLY)



// ============================================================



export const deleteChefCouponByAdmin = async (req: any, res: Response) => {



  try {



    const rawChefId = req.params.chefId;



    const chefId = Array.isArray(rawChefId) ? rawChefId[0] : rawChefId;



    const rawCouponId = req.params.couponId;



    const couponId = Array.isArray(rawCouponId) ? rawCouponId[0] : rawCouponId;







    if (!chefId || !couponId) {



      return res.status(400).json({



        success: false,



        message: "Chef ID and Coupon ID are required",



      });



    }







    const query: any = {};



    if (mongoose.Types.ObjectId.isValid(chefId)) {



      query.$or = [{ _id: chefId }, { user: chefId }];



    } else {



      query.$or = [{ name: chefId }];



    }







    const chef = await Chef.findOne(query);



    if (!chef) {



      return res.status(404).json({ success: false, message: "Chef not found" });



    }







    const before = chef.coupons?.length || 0;



    chef.coupons = (chef.coupons || []).filter(



      (c: any) => String(c._id) !== String(couponId)



    );



    const after = chef.coupons?.length || 0;







    if (before === after) {



      return res.status(404).json({ success: false, message: "Coupon not found" });



    }







    await chef.save();







    console.log(`🗑️ Admin deleted coupon ${couponId} from chef '${chef.name}'`);







    return res.json({



      success: true,



      message: "Coupon deleted successfully",



      chef,



      coupons: chef.coupons,



    });



  } catch (error: any) {



    console.error("Delete chef coupon (admin) error:", error);



    return res.status(500).json({



      success: false,



      message: "Failed to delete coupon",



    });



  }



};







// GET MY CHEF



export const getMyChef = async (req: any, res: Response) => {



  try {



    const userId = req.user.id;



    const chef = await Chef.findOne({ user: userId });







    return res.json({



      success: true,



      chef: chef || null,



    });



  } catch (error) {



    console.error("Get my chef error:", error);







    return res.status(500).json({



      message: "Server error",



    });



  }



};







// GET SPECIFIC CHEF'S COUPONS ONLY



export const getChefCoupons = async (req: Request, res: Response) => {



  try {



    const rawChefId = req.params.chefId;



    const chefId = Array.isArray(rawChefId) ? rawChefId[0] : rawChefId;



    if (!chefId) {



      return res.status(400).json({ success: false, message: "Chef ID is required" });



    }







    const query: any = {};



    if (mongoose.Types.ObjectId.isValid(chefId)) {



      query.$or = [{ _id: chefId }, { user: chefId }];



    } else {



      query.$or = [{ name: chefId }];



    }







    const chef = await Chef.findOne(query);



    if (!chef) {



      return res.status(404).json({ success: false, message: "Chef not found", coupons: [] });



    }







    const coupons = (chef.coupons || []).map((cp: any) => ({



      _id: cp._id,



      code: cp.code,



      type: cp.type === "flat" ? "FLAT" : "PERCENT",



      value: Number(cp.value) || 0,



      description: cp.description || (cp.type === "flat" ? `Flat ₹${cp.value} OFF` : `${cp.value}% OFF`),



      minOrder: Number(cp.minOrder) || 0,



      maxDiscount: Number(cp.maxDiscount) || 500,



      serviceType: normalizeCouponServiceType(cp.serviceType),



    }));







    return res.json({



      success: true,



      coupons,



      chefId: chef._id,



      chefName: chef.name,



    });



  } catch (error: any) {



    console.error("Get chef coupons error:", error);



    return res.status(500).json({



      success: false,



      message: "Failed to fetch coupons for chef",



      coupons: [],



    });



  }



};







// ================= GET SPECIFIC CHEF'S REVIEWS ONLY =================



export const getChefReviews = async (req: Request, res: Response) => {



  try {



    const rawChefId = req.params.chefId;



    const chefId = Array.isArray(rawChefId) ? rawChefId[0] : rawChefId;







    if (!chefId) {



      return res.status(400).json({



        success: false,



        message: "Chef ID is required",



        reviews: [],



      });



    }







    const query: any = {};



    if (mongoose.Types.ObjectId.isValid(chefId)) {



      query.$or = [{ _id: chefId }, { user: chefId }];



    } else {



      query.$or = [{ name: chefId }];



    }







    const chef = await Chef.findOne(query);



    if (!chef) {



      return res.status(404).json({



        success: false,



        message: "Chef not found",



        reviews: [],



      });



    }







    const rawReviews: any[] = Array.isArray(chef.reviews) ? [...chef.reviews] : [];



    rawReviews.sort((a: any, b: any) => {



      const tA = a?.createdAt ? new Date(a.createdAt).getTime() : 0;



      const tB = b?.createdAt ? new Date(b.createdAt).getTime() : 0;



      return tB - tA;



    });







    const breakdown = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 } as Record<number, number>;



    rawReviews.forEach((r: any) => {



      const rounded = Math.max(1, Math.min(5, Math.round(Number(r.rating) || 0)));



      if (rounded >= 1 && rounded <= 5) breakdown[rounded] += 1;



    });







    const totalReviews = rawReviews.length;



    let averageRating = Number(chef.averageRating) || 0;



    if (totalReviews > 0) {



      const sum = rawReviews.reduce((acc: number, r: any) => acc + (Number(r.rating) || 0), 0);



      averageRating = Number((sum / totalReviews).toFixed(1));



    } else if (!averageRating) {



      const fallback = Number(chef.rating);



      averageRating = Number.isFinite(fallback) ? fallback : 4.8;



    }







    const normalizedReviews = rawReviews.map((r: any) => ({



      _id: r?._id ? String(r._id) : undefined,



      orderId: r?.orderId || "",



      userId: r?.userId || "",



      userName: r?.userName || "Customer",



      userAvatar: r?.userAvatar || "",



      rating: Number(r?.rating) || 0,



      comment: r?.comment || "",



      images: Array.isArray(r?.images)



        ? r.images.map((img: any) => ({



            url: img?.url || "",



            cloudinaryId: img?.cloudinaryId || "",



          }))



        : [],



      createdAt: r?.createdAt || null,



    }));







    return res.json({



      success: true,



      chefId: chef._id,



      chefName: chef.name,



      averageRating,



      totalReviews,



      breakdown,



      reviews: normalizedReviews,



    });



  } catch (error: any) {



    console.error("Get chef reviews error:", error);



    return res.status(500).json({



      success: false,



      message: "Failed to fetch reviews for chef",



      reviews: [],



    });



  }



};







// APPLY SPECIFIC CHEF'S COUPON STRICTLY (with service-type guard)



export const applyChefCoupon = async (req: Request, res: Response) => {



  try {



    const { code, cartTotal, chefId, serviceType } = req.body;







    if (!code || !chefId) {



      return res.status(400).json({ success: false, message: "Coupon code and Chef ID are required" });



    }







    const query: any = {};



    if (mongoose.Types.ObjectId.isValid(chefId)) {



      query.$or = [{ _id: chefId }, { user: chefId }];



    } else {



      query.$or = [{ name: chefId }];



    }







    const chef = await Chef.findOne(query);



    if (!chef) {



      return res.status(404).json({ success: false, message: "Chef not found" });



    }







    const cleanCode = String(code).trim().toUpperCase();



    const matchedCoupon = (chef.coupons || []).find((c: any) => c.code.toUpperCase() === cleanCode);







    if (!matchedCoupon) {



      return res.status(400).json({



        success: false,



        message: `Coupon '${cleanCode}' is not valid for Chef ${chef.name}`,



      });



    }







    const cartService = String(serviceType || "").toLowerCase().trim();



    const couponService = normalizeCouponServiceType(matchedCoupon.serviceType);







    if (cartService && couponService !== cartService) {



      return res.status(400).json({



        success: false,



        notApplicable: true,



        couponCode: cleanCode,



        couponServiceType: couponService,



        cartServiceType: cartService,



        message: `Coupon '${cleanCode}' is only applicable for ${couponService.toUpperCase()} orders. Your cart is a ${cartService.toUpperCase()} order.`,



      });



    }







    const total = Number(cartTotal) || 0;



    const minOrder = Number(matchedCoupon.minOrder) || 0;



    if (total < minOrder) {



      return res.status(400).json({



        success: false,



        message: `Minimum order of ₹${minOrder} required to use this coupon`,



      });



    }







    let discount = 0;



    const couponVal = Number(matchedCoupon.value) || 0;







    if (matchedCoupon.type === "percent") {



      discount = Math.round((total * couponVal) / 100);



      const maxDiscount = Number(matchedCoupon.maxDiscount) || 500;



      if (maxDiscount > 0 && discount > maxDiscount) {



        discount = maxDiscount;



      }



    } else {



      discount = couponVal;



    }







    if (discount > total) {



      discount = total;



    }







    return res.json({



      success: true,



      message: `Coupon '${cleanCode}' applied successfully!`,



      code: cleanCode,



      discount,



      chefId: chef._id,



      chefName: chef.name,



      serviceType: couponService,



    });



  } catch (error: any) {



    console.error("Apply chef coupon error:", error);



    return res.status(500).json({



      success: false,



      message: "Server error while applying coupon",



    });



  }



};