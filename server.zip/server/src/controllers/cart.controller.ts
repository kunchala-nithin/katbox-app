import { Request, Response } from 'express';
import Cart from '../models/Cart';

// ✅ Helper: normalize the instructionTag from HomeMadeOrderReview
// ("less" | "medium" | "very" | "noonion" | "") into the
// specialInstructions.spice + noOnionsGarlic shape already used by the schema.
const normalizeSpecialInstructionsFromOrderDetails = (orderDetails: any) => {
  const tagRaw = String(
    orderDetails?.instructionTag ||
    orderDetails?.selectedSpice ||
    orderDetails?.specialInstruction?.tag ||
    ''
  ).trim().toLowerCase();
  const noOnionFlag =
    tagRaw === 'noonion' ||
    !!orderDetails?.noOnionsGarlic ||
    !!orderDetails?.specialInstruction?.noOnion;
  // Preserve the spice tag the same way the existing catering branch does.
  // If tag is "noonion", we set spice to "noonion" AND noOnionsGarlic=true
  // (matches existing CartScreen resolveSpiceEmoji + resolveSpecialInstruction logic).
  let spice = '';
  if (tagRaw === 'less' || tagRaw === 'medium' || tagRaw === 'very') {
    spice = tagRaw;
  } else if (tagRaw === 'noonion') {
    spice = 'noonion';
  } else if (tagRaw) {
    spice = tagRaw;
  }
  // The free-text description the customer typed.
  const notes = String(
    orderDetails?.chefNotes ||
    orderDetails?.notes ||
    orderDetails?.specialInstruction?.text ||
    orderDetails?.specialInstructionText ||
    ''
  ).trim();
  return { spice, noOnionsGarlic: noOnionFlag, notes };
};

// Parse item payloads safely and preserve all item metadata, including combo
// identifiers and component flags. Supports JSON arrays and normal arrays.
const normalizeCartItems = (rawItems: any): any[] => {
  let parsedItems = rawItems;

  if (typeof parsedItems === 'string') {
    try {
      parsedItems = JSON.parse(parsedItems);
    } catch {
      return [];
    }
  }

  if (!Array.isArray(parsedItems)) return [];

  return parsedItems.map((item: any) => {
    if (!item || typeof item !== 'object' || Array.isArray(item)) return item;
    // Keep the complete object intact; this includes isComboComponent,
    // comboName, comboId, comboKey, comboComponent, and future metadata.
    return { ...item };
  });
};

export const addToCart = async (req: Request, res: Response) => {
  try {
    const userId =
      (req as any).user?.userId ||
      (req as any).user?.id ||
      (req as any).user?._id;
    if (!userId)
      return res.status(401).json({ success: false, message: "Unauthorized" });
    // ✅ Look for explicit serviceType mapping from payload
    const { serviceType, couponCode, discount } = req.body;
    // ✅ ITEM-BASED FLOWS: homemade, mealbox and quickbites all share the same
    // item-list-based cart structure. QuickBites is a sibling of homemade and
    // must persist the same delivery timestamps + slot fields.
    const isItemBasedFlow =
      serviceType === 'homemade' ||
      serviceType === 'mealbox' ||
      serviceType === 'quickbites';
    if (isItemBasedFlow) {
      const { chefId, chefName, chefImage, items, totalItems, totalPrice, menu, selections, addons, orderDetails, userPhone, alternatePhone } = req.body;
      // Calculate dynamic discount metrics safely
      const appliedDiscount = Number(discount || 0);
      const calculatedFinalTotal = Math.max(0, Number(totalPrice || 0) - appliedDiscount);
      const resolvedUserPhone = userPhone || orderDetails?.contactPhone || (req as any).user?.phone || '';
      const resolvedAltPhone = alternatePhone || orderDetails?.alternatePhone || '';
      // ✅ Homemade / QuickBites-only: resolve delivery date & slot from top-level body OR nested orderDetails
      const resolvedDeliveryDate = String(
        req.body.deliveryDate ||
        orderDetails?.deliveryDate ||
        orderDetails?.deliveryDateKey ||
        ''
      );
      const resolvedDeliverySlot = String(
        req.body.deliverySlot ||
        orderDetails?.deliverySlot ||
        orderDetails?.deliveryTimeSlot ||
        ''
      );
      // ✅ NEW: Resolve the absolute estimated delivery timestamp + window + QuickBites flag.
      // The client (HomeMadeOrderReview) sends these for QuickBites so the cart
      // doc carries a fixed Date that the CartScreen can render dynamically.
      const estimatedDeliveryAtMsRaw = req.body.estimatedDeliveryAtMs;
      const parsedEstimatedDeliveryAtMs = Number(estimatedDeliveryAtMsRaw);
      const resolvedEstimatedDeliveryAt =
        Number.isFinite(parsedEstimatedDeliveryAtMs) && parsedEstimatedDeliveryAtMs > 0
          ? new Date(parsedEstimatedDeliveryAtMs)
          : undefined;
      const resolvedDeliveryWindowMinutes = Number(req.body.deliveryWindowMinutes) || 0;
      const resolvedIsQuickBites =
        String(req.body.isQuickBites || '').toLowerCase() === 'true' ||
        String(orderDetails?.isQuickBites || '').toLowerCase() === 'true' ||
        serviceType === 'quickbites';
      // ✅ Only homemade / quickbites flows carry the delivery date / slot /
      // estimatedDeliveryAt info. Mealbox carts keep these fields empty.
      const carriesDeliveryMeta =
        serviceType === 'homemade' || serviceType === 'quickbites';
      // ✅ NEW: Normalize special instructions from HomeMadeOrderReview's
      // orderDetails.instructionTag / orderDetails.chefNotes into the
      // schema's existing specialInstructions sub-document (no duplicates).
      const normalizedSpecialInstructions =
        normalizeSpecialInstructionsFromOrderDetails(orderDetails);
      // Clear out active current instances sitting in standard active workflow session
      await Cart.deleteMany({ user: userId, status: "in-cart" });
      const newHomemadeCart = new Cart({
        user: userId,
        userPhone: resolvedUserPhone,
        alternatePhone: resolvedAltPhone,
        serviceType,
        chefId,
        chefName,
        // ✅ NEW: persist chef/vendor image for homemade / quickbites / mealbox
        chefImage: chefImage || '',
        items: normalizeCartItems(items),
        totalItems,
        totalPrice,
        menu,
        selections,
        addons,
        orderDetails,
        // ✅ NEW: populate the existing specialInstructions sub-doc for
        // item-based flows too (previously only catering wrote here).
        specialInstructions: normalizedSpecialInstructions,
        status: 'in-cart',
        couponCode: couponCode || null,
        discount: appliedDiscount,
        totalPriceAfterDiscount: calculatedFinalTotal,
        // ✅ Only meaningful for homemade / quickbites; harmless for mealbox (stays empty string)
        deliveryDate: carriesDeliveryMeta ? resolvedDeliveryDate : '',
        deliverySlot: carriesDeliveryMeta ? resolvedDeliverySlot : '',
        // ✅ NEW: Absolute timestamp for dynamic display in CartScreen
        estimatedDeliveryAt: carriesDeliveryMeta ? resolvedEstimatedDeliveryAt : undefined,
        deliveryWindowMinutes: carriesDeliveryMeta ? resolvedDeliveryWindowMinutes : 0,
        isQuickBites: carriesDeliveryMeta ? resolvedIsQuickBites : false
      });
      const savedHomemade = await newHomemadeCart.save();
      return res.status(201).json({
        success: true,
        cart: [savedHomemade],
      });
    }
    const {
      menu,
      restaurant,
      selections,
      addons, // ✅ DESTRUCTURED ADDONS PIPELINE VARIABLE
      totalItems,
      orderDetails,
      type,
      finalPrice,
      deliveryPrice,
      deliveryType,
      extraItems, // ✅ NEW
      userPhone,
      alternatePhone
    } = req.body;
    const guests = Number(orderDetails?.guests || 0);
    // ✅ CALCULATE BASE PRICE FROM CURRENT SELECTIONS PIPELINE
    const basePlatterTotal = Number(finalPrice || 0) * guests;
    // ✅ DYNAMIC COMPILATION OF ADDONS CALCULATED ACCORDING TO USER CONFIG: (Addon Price * Addon Selected Qty) * Selected Guest Count
    const addonsTotal = (addons || []).reduce((sum: number, currentAddon: any) => {
      const addonPrice = Number(currentAddon.price || 0);
      const addonCount = Number(currentAddon.count || 0);
      return sum + (addonPrice * addonCount * guests);
    }, 0);
    // ✅ TOTAL PRICE MATCHES EXACT MATHEMATICAL MODEL: (Plate Price * Guests) + (Addon Plate Matrix * Guests) + Delivery Charges
    const totalPrice = basePlatterTotal + addonsTotal + Number(deliveryPrice || 0);
    const appliedDiscount = Number(discount || 0);
    const calculatedFinalTotal = Math.max(0, totalPrice - appliedDiscount);
    const resolvedUserPhone = userPhone || orderDetails?.contactPhone || (req as any).user?.phone || '';
    const resolvedAltPhone = alternatePhone || orderDetails?.alternatePhone || '';
    const resolvedDeliveryType = String(deliveryType || orderDetails?.delivery || "Standard").trim();
    console.log("🔥 EXTRA ITEMS FROM FRONTEND:", extraItems);
    // ✅🔥 DELETE OLD CART (PREVENT DUPLICATES)
    await Cart.deleteMany({ user: userId, status: "in-cart" });
    const newCart = new Cart({
      user: userId,
      userPhone: resolvedUserPhone,
      alternatePhone: resolvedAltPhone,
      restaurant,
      menu,
      selections,
      addons: addons || [],
      orderDetails,
      specialInstructions: {
        spice: orderDetails?.selectedSpice || "",
        noOnionsGarlic: !!orderDetails?.noOnionsGarlic,
        notes: orderDetails?.notes || "",
      },
      totalItems,
      totalPrice,
      deliveryPrice: Number(deliveryPrice || 0),
      // ✅🔥 STORE EXTRA ITEMS
      extraItems: extraItems || 0,
      type: type || "veg",
      serviceType: 'catering',
      deliveryType: resolvedDeliveryType,
      couponCode: couponCode || null,
      discount: appliedDiscount,
      totalPriceAfterDiscount: calculatedFinalTotal,
      // ✅ Catering flow untouched — leave deliveryDate/Slot empty
      deliveryDate: '',
      deliverySlot: '',
      // ✅ NEW: Catering doesn't use the estimatedDeliveryAt timestamp
      estimatedDeliveryAt: undefined,
      deliveryWindowMinutes: 0,
      isQuickBites: false
    });
    const saved = await newCart.save();
    res.status(201).json({
      success: true,
      cart: [saved],
    });
  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
};

export const getUserCart = async (req: Request, res: Response) => {
  try {
    const userId =
      (req as any).user?.userId ||
      (req as any).user?.id ||
      (req as any).user?._id;
    const cart = await Cart.find({
      user: userId,
      status: 'in-cart'
    }).sort({ createdAt: -1 });
    res.json({ success: true, cart });
  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
};

export const updateCart = async (req: Request, res: Response) => {
  try {
    const { cartId } = req.params;
    const { serviceType, couponCode, discount } = req.body;
    // ✅ ITEM-BASED FLOWS: homemade, mealbox and quickbites all share the
    // same item-list-based structure. QuickBites is a sibling of homemade.
    const isItemBasedFlow =
      serviceType === 'homemade' ||
      serviceType === 'mealbox' ||
      serviceType === 'quickbites';
    if (isItemBasedFlow) {
      const { chefId, chefName, chefImage, items, totalItems, totalPrice, menu, selections, addons, orderDetails, userPhone, alternatePhone } = req.body;
      const appliedDiscount = Number(discount || 0);
      const calculatedFinalTotal = Math.max(0, Number(totalPrice || 0) - appliedDiscount);
      const resolvedUserPhone = userPhone || orderDetails?.contactPhone || '';
      const resolvedAltPhone = alternatePhone || orderDetails?.alternatePhone || '';
      // ✅ Homemade / QuickBites-only: resolve delivery date & slot from top-level body OR nested orderDetails
      const resolvedDeliveryDate = String(
        req.body.deliveryDate ||
        orderDetails?.deliveryDate ||
        orderDetails?.deliveryDateKey ||
        ''
      );
      const resolvedDeliverySlot = String(
        req.body.deliverySlot ||
        orderDetails?.deliverySlot ||
        orderDetails?.deliveryTimeSlot ||
        ''
      );
      // ✅ NEW: Same timestamp handling as addToCart
      const estimatedDeliveryAtMsRaw = req.body.estimatedDeliveryAtMs;
      const parsedEstimatedDeliveryAtMs = Number(estimatedDeliveryAtMsRaw);
      const resolvedEstimatedDeliveryAt =
        Number.isFinite(parsedEstimatedDeliveryAtMs) && parsedEstimatedDeliveryAtMs > 0
          ? new Date(parsedEstimatedDeliveryAtMs)
          : undefined;
      const resolvedDeliveryWindowMinutes = Number(req.body.deliveryWindowMinutes) || 0;
      const resolvedIsQuickBites =
        String(req.body.isQuickBites || '').toLowerCase() === 'true' ||
        String(orderDetails?.isQuickBites || '').toLowerCase() === 'true' ||
        serviceType === 'quickbites';
      // ✅ Only homemade / quickbites flows carry the delivery date / slot /
      // estimatedDeliveryAt info. Mealbox carts keep these fields empty.
      const carriesDeliveryMeta =
        serviceType === 'homemade' || serviceType === 'quickbites';
      // ✅ NEW: Same special-instructions normalization as addToCart.
      const normalizedSpecialInstructions =
        normalizeSpecialInstructionsFromOrderDetails(orderDetails);
      const updatedHomemade = await Cart.findByIdAndUpdate(
        cartId,
        {
          chefId,
          chefName,
          // ✅ NEW: persist chef/vendor image for homemade / quickbites / mealbox
          chefImage: chefImage || '',
          userPhone: resolvedUserPhone,
          alternatePhone: resolvedAltPhone,
          items: normalizeCartItems(items),
          totalItems,
          totalPrice,
          menu,
          selections,
          addons,
          orderDetails,
          // ✅ NEW: populate the existing specialInstructions sub-doc for
          // item-based flows too (previously only catering wrote here).
          specialInstructions: normalizedSpecialInstructions,
          serviceType,
          couponCode: couponCode || null,
          discount: appliedDiscount,
          totalPriceAfterDiscount: calculatedFinalTotal,
          // ✅ Preserve delivery date & slot on every update for homemade / quickbites; empty for mealbox
          deliveryDate: carriesDeliveryMeta ? resolvedDeliveryDate : '',
          deliverySlot: carriesDeliveryMeta ? resolvedDeliverySlot : '',
          // ✅ NEW: Preserve the absolute timestamp fields
          estimatedDeliveryAt: carriesDeliveryMeta ? resolvedEstimatedDeliveryAt : undefined,
          deliveryWindowMinutes: carriesDeliveryMeta ? resolvedDeliveryWindowMinutes : 0,
          isQuickBites: carriesDeliveryMeta ? resolvedIsQuickBites : false
        },
        { new: true }
      );
      return res.json({
        success: true,
        message: 'Cart updated',
        cart: updatedHomemade,
      });
    }
    const {
      menu,
      restaurant,
      selections,
      addons,
      orderItemDetails,
      orderDetails,
      type,
      finalPrice,
      deliveryPrice,
      deliveryType,
      extraItems,
      userPhone,
      alternatePhone
    } = req.body;
    const guests = Number(orderDetails?.guests || 0);
    // ✅ RECOMPUTE IN STRICT ORDER MATCHING ADD INTERPOLATION LAYOUT LAWS
    const basePlatterTotal = Number(finalPrice || 0) * guests;
    const addonsTotal = (addons || []).reduce((sum: number, currentAddon: any) => {
      const addonPrice = Number(currentAddon.price || 0);
      const addonCount = Number(currentAddon.count || 0);
      return sum + (addonPrice * addonCount * guests);
    }, 0);
    const totalPrice = basePlatterTotal + addonsTotal + Number(deliveryPrice || 0);
    const appliedDiscount = Number(discount || 0);
    const calculatedFinalTotal = Math.max(0, totalPrice - appliedDiscount);
    const resolvedUserPhone = userPhone || orderDetails?.contactPhone || '';
    const resolvedAltPhone = alternatePhone || orderDetails?.alternatePhone || '';
    const resolvedDeliveryType = String(deliveryType || orderDetails?.delivery || "Standard").trim();
    const updated = await Cart.findByIdAndUpdate(
      cartId,
      {
        menu,
        restaurant,
        userPhone: resolvedUserPhone,
        alternatePhone: resolvedAltPhone,
        selections,
        addons: addons || [],
        orderDetails,
        specialInstructions: {
          spice: orderDetails?.selectedSpice || '',
          noOnionsGarlic: !!orderDetails?.noOnionsGarlic,
          notes: orderDetails?.notes || '',
        },
        totalItems: selections?.reduce
          ? selections.reduce(
              (acc: number, cat: any) =>
                acc +
                (cat.selected?.length || 0) +
                (cat.extraSelected?.length || 0), 
              0
            )
          : 0,
        totalPrice,
        deliveryPrice: Number(deliveryPrice || 0),
        deliveryType: resolvedDeliveryType,
        // ✅🔥 UPDATE EXTRA ITEMS
        extraItems: extraItems || 0,
        type: type || 'veg',
        couponCode: couponCode || null,
        discount: appliedDiscount,
        totalPriceAfterDiscount: calculatedFinalTotal,
        // ✅ Catering flow untouched — keep deliveryDate/Slot empty
        deliveryDate: '',
        deliverySlot: '',
        // ✅ NEW: Catering doesn't use the timestamp fields
        estimatedDeliveryAt: undefined,
        deliveryWindowMinutes: 0,
        isQuickBites: false
      },
      { new: true }
    );
    res.json({
      success: true,
      message: 'Cart updated',
      cart: updated,
    });
  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
};

export const deleteCart = async (req: Request, res: Response) => {
  try {
    const { cartId } = req.params;
    await Cart.findByIdAndDelete(cartId);
    res.json({
      success: true,
      message: 'Cart permanently deleted',
    });
  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
};
